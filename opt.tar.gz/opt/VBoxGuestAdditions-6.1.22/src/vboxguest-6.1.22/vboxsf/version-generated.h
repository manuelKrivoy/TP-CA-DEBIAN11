#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 6
#define VBOX_VERSION_MINOR 1
#define VBOX_VERSION_BUILD 22
#define VBOX_VERSION_STRING_RAW "6.1.22"
#define VBOX_VERSION_STRING "6.1.22"
#define VBOX_API_VERSION_STRING "6_1"

#define VBOX_BUILD_SERVER_BUILD 1

#endif
