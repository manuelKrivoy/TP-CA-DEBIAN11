#!/usr/bin/env bash
#backup_full.sh - Backup .tar.gz con fecha YYYYMMDD
# Uso:
# backup_full.sh -s <origen> -d <destino>
# backup_full.sh help

set -e

help() {
	cat <<EOF
Uso:
$(basename "$0") -s <origen> -d <destino>
$(basename "$0") <origen> <destino>

Ejemplo:
$(basename "$0") -s /var/log -d backup_dir
$(basename "$0") /www_dir /backup_dir

EOF
}


# PARSEO
SRC=""
DST=""

if [ "$#" -eq 2 ] && ["${1#-}" = "$1" ]; then
	SRC="$1"
	DST="$2"
fi


while [ "$#" -gt 0 ]; do
	case "$1" in
	-s|--source) SRC="$2"; shift 2;;
	-d|--dest) DST="$2"; shift 2;;
	-h|--help|-help)
	 help; exit 0 ;;
	*) 
	shift ;;
	esac
done

if [ -z "$SRC" ]; then
	echo "ERROR falta ingresar origen"
	help
	exit 1
fi

if [ -z "$DST" ]; then
	echo "ERROR falta ingresar destino"
	help
	exit 1
fi

# validaciones
if [ ! -d "$SRC" ]; then
	echo "NO EXISTE ORIGEN $SRC"; exit 2;
fi

if [ ! -d "$DST" ]; then
	echo "  NO EXISTE DESTINO $DST"; exit 3;
fi

DST_REAL=$(readlink -f "$DST")
if ! grep -qs " $DST_REAL " /proc/mounts; then
	echo " DESTINO NO MONTADO $DST_REAL"; exit 4
fi


# armado de bu
DATE=$(date +%Y%m%d)
SRC_REAL=$(readlink -f "$SRC")
BASE=$(basename "$SRC_REAL")
OUT="${DST_REAL%/}/${BASE}_bkp_${DATE}.tar.gz"

echo "Creando BU '$SRC_REAL' -> '$OUT' ... "
tar -czf "$OUT" -C "$(dirname "$SRC_REAL")" "$BASE"
echo "OK: $OUT"




